﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BotControls : MonoBehaviour {
    public float speed = 2.0f;
    public float boundY = 3.7f;
    private Rigidbody2D rb2d;
    private Rigidbody2D d;

    GameObject theBall;

    // Use this for initialization
    void Start()
    {
        rb2d = GetComponent<Rigidbody2D>();
        theBall = GameObject.FindGameObjectWithTag("Ball");
        d = theBall.GetComponent<Rigidbody2D>();
    }

    // Update is called once per frame
    void Update()
    {
        var vel = rb2d.velocity;
        var pos = transform.position;

        if (d.position.y > pos.y)
        {
            vel.y = speed;
        }
        else if (d.position.y < pos.y)
        {
            vel.y = -speed;
        }
        else
        {
            vel.y = 0;
        }
        rb2d.velocity = vel;

        if (pos.y > boundY)
        {
            pos.y = boundY;
        }
        else if (pos.y < -boundY)
        {
            pos.y = -boundY;
        }
        transform.position = pos;
    }
}