﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class HelpMenu : MonoBehaviour {
    public GUISkin layout;

    private void OnGUI()
    {
        GUI.skin = layout;
        GUI.Label(new Rect(0, 0, Screen.width, Screen.height), "\t\t\tHelp Menu\n\n\n" +
            "\tYou are the green lightsaber fighting the evil red bot saber\n" +
            "\t\t\tGOOD LUCK!!\n\n" +
            "\tw - Moves Up\n" +
            "\ts - Moves Down\n" +
            "\tFirst player to 10 points wins\n\n" +
            "\tClick start to begin");
        if (GUI.Button(new Rect(Screen.width / 2 - 60, Screen.height - 200, 120, 53), "Start"))
        {
            SceneManager.LoadScene(1);
        }
    }
}
